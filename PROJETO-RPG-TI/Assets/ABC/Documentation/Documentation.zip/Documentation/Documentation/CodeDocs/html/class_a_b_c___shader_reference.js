var class_a_b_c___shader_reference =
[
    [ "RefreshCustomReference", "class_a_b_c___shader_reference.html#adf750e7c66e472faf9ccb0c6002ded22", null ],
    [ "refName", "class_a_b_c___shader_reference.html#a192b93c0be0be029d79e063ed2527ded", null ],
    [ "refUpdateDateTime", "class_a_b_c___shader_reference.html#ace34562e20ef2c326709852fe5281f67", null ],
    [ "refVal", "class_a_b_c___shader_reference.html#afd91fc944b09433307a831106cac48e4", null ],
    [ "Shader", "class_a_b_c___shader_reference.html#af2a3ac2dd9491642e98ac47cda450619", null ]
];