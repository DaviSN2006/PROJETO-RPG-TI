var class_a_b_c___controller_1_1_weapon_1_1_block_stat_modifications =
[
    [ "arithmeticOperator", "class_a_b_c___controller_1_1_weapon_1_1_block_stat_modifications.html#ad09891d1e40f52fe136a3a3d3acdd07a", null ],
    [ "finalStatValueModification", "class_a_b_c___controller_1_1_weapon_1_1_block_stat_modifications.html#acc6f15dda747127c76f5fd0d56782c0c", null ],
    [ "modificationValue", "class_a_b_c___controller_1_1_weapon_1_1_block_stat_modifications.html#ad199181d52285a41d33c50a57d5a747f", null ],
    [ "modifyByPercentOrBaseValue", "class_a_b_c___controller_1_1_weapon_1_1_block_stat_modifications.html#a7290031fe91391f3aa4e746c81f76cf4", null ],
    [ "statIntegrationType", "class_a_b_c___controller_1_1_weapon_1_1_block_stat_modifications.html#aa7116a2c3b60cb2bc0e0d0952d6b8003", null ],
    [ "statName", "class_a_b_c___controller_1_1_weapon_1_1_block_stat_modifications.html#ab6db82de45839c1c936795e333e2f808", null ]
];