var class_a_b_c___save_manager_1_1_save_master =
[
    [ "includeObjTags", "class_a_b_c___save_manager_1_1_save_master.html#a979beaf862bc78ebc486a92218e02704", null ],
    [ "loadEnableState", "class_a_b_c___save_manager_1_1_save_master.html#a913a54f82ba7915eb67ab835520277d5", null ],
    [ "loadScene", "class_a_b_c___save_manager_1_1_save_master.html#a737d810fa628b199bc5956fdb38d7ca0", null ],
    [ "loadTransform", "class_a_b_c___save_manager_1_1_save_master.html#ae719e0b8da36fd571c079cb79634dc14", null ],
    [ "persistantEntityNames", "class_a_b_c___save_manager_1_1_save_master.html#a83b219353424629387b6051de07fec94", null ],
    [ "saveDate", "class_a_b_c___save_manager_1_1_save_master.html#a60186b80037da1472829fd0166f89927", null ],
    [ "savedData", "class_a_b_c___save_manager_1_1_save_master.html#a494a05a08cb2337e8077211dfc745410", null ],
    [ "saveName", "class_a_b_c___save_manager_1_1_save_master.html#a2ab93887352e01a26d972207ef2be0d3", null ],
    [ "sceneName", "class_a_b_c___save_manager_1_1_save_master.html#a009ac9f10dcdc5f195f799cd8bd69054", null ]
];