var class_a_b_c___camera_reference =
[
    [ "RefreshCustomReference", "class_a_b_c___camera_reference.html#aae49e2ef19d9874d1707502f5c3b2a4c", null ],
    [ "refName", "class_a_b_c___camera_reference.html#ad77d6a08febea50e1744e49eba1705ec", null ],
    [ "refUpdateDateTime", "class_a_b_c___camera_reference.html#a95da9d94cb170686ea14d051fb9a8dfb", null ],
    [ "refVal", "class_a_b_c___camera_reference.html#a06e5cfb2a60ff4ac5a90f6cf41d77d83", null ],
    [ "Camera", "class_a_b_c___camera_reference.html#afe34e42139ae35268eb54c77ea2a74ca", null ]
];