var class_a_b_c___texture_reference =
[
    [ "RefreshCustomReference", "class_a_b_c___texture_reference.html#ab662316780ea470265bf97997b1e1bf1", null ],
    [ "refName", "class_a_b_c___texture_reference.html#aa0c51fd3bdf05ddd4c22381f1953fa2e", null ],
    [ "refUpdateDateTime", "class_a_b_c___texture_reference.html#a3daa2f532e5f03eb20726e1654ba3031", null ],
    [ "refVal", "class_a_b_c___texture_reference.html#ad840667749e79ac1fd607173ea20c950", null ],
    [ "Texture", "class_a_b_c___texture_reference.html#a3824f73626775a35050e28abf19d0e9e", null ]
];