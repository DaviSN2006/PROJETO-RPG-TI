var class_a_b_c___text_reference =
[
    [ "RefreshCustomReference", "class_a_b_c___text_reference.html#a848388f30d1cb3c564534daada462e93", null ],
    [ "refName", "class_a_b_c___text_reference.html#a90d03760c39afba0a73d483d49510f7b", null ],
    [ "refUpdateDateTime", "class_a_b_c___text_reference.html#a65a8d49cdf5cbfba503d073f08b8188c", null ],
    [ "refVal", "class_a_b_c___text_reference.html#a04638b8d81046a70748206012b0d0a62", null ],
    [ "Text", "class_a_b_c___text_reference.html#a47ada2159038c79927205c8a71e95b24", null ]
];