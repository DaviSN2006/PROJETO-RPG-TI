var class_a_b_c___global_element =
[
    [ "GlobalElementType", "class_a_b_c___global_element.html#ad9c9a47ac156772d51ae6da04cb2483b", [
      [ "Weapon", "class_a_b_c___global_element.html#ad9c9a47ac156772d51ae6da04cb2483ba18c83669920215a818638ad0e5421e4b", null ],
      [ "Abilities", "class_a_b_c___global_element.html#ad9c9a47ac156772d51ae6da04cb2483bac5350ccbd8c29ba37c684f3157173694", null ],
      [ "Effect", "class_a_b_c___global_element.html#ad9c9a47ac156772d51ae6da04cb2483baa62d22910732d5343689f5117999abfa", null ],
      [ "AIRules", "class_a_b_c___global_element.html#ad9c9a47ac156772d51ae6da04cb2483ba6b437b10d7228a48a706fa116e1c1335", null ]
    ] ],
    [ "RefreshUniqueIDs", "class_a_b_c___global_element.html#a3bd3714c7cc3fd8a6314d4de33e74e00", null ],
    [ "createdBy", "class_a_b_c___global_element.html#a144ddcd97c125442d9dbc53e211eac87", null ],
    [ "creationDate", "class_a_b_c___global_element.html#a106aefecd607fd3b538c06314a49b109", null ],
    [ "ElementAbilities", "class_a_b_c___global_element.html#a9ed874998346a1c8ae6e113968ff449f", null ],
    [ "ElementAIRules", "class_a_b_c___global_element.html#aac045933984fd4c807efd6233759d290", null ],
    [ "elementDescription", "class_a_b_c___global_element.html#a60eb768b296ee6f0db9b3cfdd31a0170", null ],
    [ "ElementEffects", "class_a_b_c___global_element.html#a2ce3f53c3fdd749bdafc7a45c8c9478a", null ],
    [ "elementIcon", "class_a_b_c___global_element.html#a5875018c44572ea83eef7531854d8a9f", null ],
    [ "elementTags", "class_a_b_c___global_element.html#a0895bf75ac934cd19eff4966047f9058", null ],
    [ "elementType", "class_a_b_c___global_element.html#a6f9c9ddb39ecab8f829b5e79fb5e3af2", null ],
    [ "ElementWeapon", "class_a_b_c___global_element.html#a5ea1940427890258336881821f8a6ee9", null ],
    [ "officialABC", "class_a_b_c___global_element.html#a32c0654f61d352f5b3d44416dee51038", null ],
    [ "showWeaponPreview", "class_a_b_c___global_element.html#ae7db3994e71299f5d10632ec728de90d", null ]
];