var class_a_b_c___freeze_rotation =
[
    [ "FixedUpdate", "class_a_b_c___freeze_rotation.html#ae1036057b7d24cef9a118452bcee4a43", null ],
    [ "Start", "class_a_b_c___freeze_rotation.html#a5770353f493eab48ef12577166bb4f00", null ],
    [ "meTransform", "class_a_b_c___freeze_rotation.html#a2ea47fb161526a4bad1e63a5f6d2968d", null ],
    [ "startRotation", "class_a_b_c___freeze_rotation.html#a4c314bce4473d77323b945dc63c1c525", null ]
];