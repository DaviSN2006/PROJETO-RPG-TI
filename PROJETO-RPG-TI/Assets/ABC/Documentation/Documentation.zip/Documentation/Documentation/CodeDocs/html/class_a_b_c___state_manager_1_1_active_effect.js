var class_a_b_c___state_manager_1_1_active_effect =
[
    [ "ActiveEffect", "class_a_b_c___state_manager_1_1_active_effect.html#a25e74f860e2dca0f61d81de2b41898b5", null ],
    [ "abilityName", "class_a_b_c___state_manager_1_1_active_effect.html#a7b2feb193a694b6dd4e6502c6ff84efb", null ],
    [ "ActivateCoroutine", "class_a_b_c___state_manager_1_1_active_effect.html#a2c6cc3162121172c1555151fccc26b5c", null ],
    [ "activationTime", "class_a_b_c___state_manager_1_1_active_effect.html#a626f485a84437bda2ffde0a7bb43859b", null ],
    [ "effect", "class_a_b_c___state_manager_1_1_active_effect.html#a4048dfc18d7ebb1521eed6cbb115bdeb", null ],
    [ "hitPoint", "class_a_b_c___state_manager_1_1_active_effect.html#af412d2ad13d601478d7e10e622bc7b6d", null ]
];