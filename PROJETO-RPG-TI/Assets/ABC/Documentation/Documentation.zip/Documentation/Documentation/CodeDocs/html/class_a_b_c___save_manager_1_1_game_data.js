var class_a_b_c___save_manager_1_1_game_data =
[
    [ "GameData", "class_a_b_c___save_manager_1_1_game_data.html#ae3ffb890cad122fc6aed54de381d8b7b", null ],
    [ "dataABC_Controller", "class_a_b_c___save_manager_1_1_game_data.html#ade7dcb87e8039046ea910c6079b4328b", null ],
    [ "dataABC_StateManager", "class_a_b_c___save_manager_1_1_game_data.html#a9f5182508e86a73854e70bbe392b7253", null ],
    [ "dataABC_WeaponPickUp", "class_a_b_c___save_manager_1_1_game_data.html#aef093e706c56f2178545202eb6bc79f3", null ],
    [ "objEnabled", "class_a_b_c___save_manager_1_1_game_data.html#ae189ac2c436079fbdb1d6a30084ade26", null ],
    [ "objID", "class_a_b_c___save_manager_1_1_game_data.html#afc2582e14e31ab574a4b0a96ecc4942c", null ],
    [ "objName", "class_a_b_c___save_manager_1_1_game_data.html#a7ea4e2d5e4781bb7c6b65ef4b97fa848", null ],
    [ "transformPosition", "class_a_b_c___save_manager_1_1_game_data.html#a0800f79f1ad242256956a931a4c53cd7", null ],
    [ "transformRotation", "class_a_b_c___save_manager_1_1_game_data.html#a86b204e3b6afc8638653d67ffbe731aa", null ]
];