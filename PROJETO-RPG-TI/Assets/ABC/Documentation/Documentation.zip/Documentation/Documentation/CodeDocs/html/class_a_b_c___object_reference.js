var class_a_b_c___object_reference =
[
    [ "RefreshCustomReference", "class_a_b_c___object_reference.html#a6b3834ef49fa673e3579dfc3db4eed6e", null ],
    [ "refName", "class_a_b_c___object_reference.html#a8d114d3183cbcbc03ad25536af9a3121", null ],
    [ "refUpdateDateTime", "class_a_b_c___object_reference.html#a91e6095bb78a722cb1ac96377ba3cc15", null ],
    [ "refVal", "class_a_b_c___object_reference.html#a90bf8f3227634f3f201589223cc1ffb0", null ],
    [ "Object", "class_a_b_c___object_reference.html#a772af42272d53e7b4fe5491c154b889b", null ]
];