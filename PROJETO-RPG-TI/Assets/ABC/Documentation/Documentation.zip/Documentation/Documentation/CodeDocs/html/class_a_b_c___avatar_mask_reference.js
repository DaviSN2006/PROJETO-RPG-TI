var class_a_b_c___avatar_mask_reference =
[
    [ "RefreshCustomReference", "class_a_b_c___avatar_mask_reference.html#af39bcee09eada1a12435fd7bfc9f63e6", null ],
    [ "refName", "class_a_b_c___avatar_mask_reference.html#a1138c330468b0b7c892cde7272ec92c2", null ],
    [ "refUpdateDateTime", "class_a_b_c___avatar_mask_reference.html#a999ee6c29907cc6f5dd2334317305b25", null ],
    [ "refVal", "class_a_b_c___avatar_mask_reference.html#a81e578694b555b0ea382fa5c6163dc91", null ],
    [ "AvatarMask", "class_a_b_c___avatar_mask_reference.html#a6649d8a3ce9a9d2e6350a608bb43ef5b", null ]
];